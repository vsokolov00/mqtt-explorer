/********************************************************************************
** Form generated from reading UI file 'messagepool.ui'
**
** Created by: Qt User Interface Compiler version 5.12.8
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MESSAGEPOOL_H
#define UI_MESSAGEPOOL_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTreeView>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MessagePool
{
public:
    QWidget *centralwidget;
    QVBoxLayout *verticalLayout_2;
    QHBoxLayout *horizontalLayout;
    QVBoxLayout *tree;
    QTreeView *messageList;
    QLineEdit *topic;
    QLineEdit *message;
    QPushButton *pushButton_3;
    QVBoxLayout *verticalLayout_5;
    QLabel *label;
    QListWidget *listWidget;
    QLabel *label_2;
    QLineEdit *path;
    QLabel *label_3;
    QPlainTextEdit *msg_to_publish;
    QPushButton *pushButton;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MessagePool)
    {
        if (MessagePool->objectName().isEmpty())
            MessagePool->setObjectName(QString::fromUtf8("MessagePool"));
        MessagePool->resize(1118, 643);
        centralwidget = new QWidget(MessagePool);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        verticalLayout_2 = new QVBoxLayout(centralwidget);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(-1, 0, -1, -1);
        tree = new QVBoxLayout();
        tree->setObjectName(QString::fromUtf8("tree"));
        tree->setContentsMargins(0, -1, -1, -1);
        messageList = new QTreeView(centralwidget);
        messageList->setObjectName(QString::fromUtf8("messageList"));
        messageList->setSizeAdjustPolicy(QAbstractScrollArea::AdjustToContentsOnFirstShow);
        messageList->header()->setCascadingSectionResizes(true);

        tree->addWidget(messageList);

        topic = new QLineEdit(centralwidget);
        topic->setObjectName(QString::fromUtf8("topic"));

        tree->addWidget(topic);

        message = new QLineEdit(centralwidget);
        message->setObjectName(QString::fromUtf8("message"));

        tree->addWidget(message);

        pushButton_3 = new QPushButton(centralwidget);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));

        tree->addWidget(pushButton_3);


        horizontalLayout->addLayout(tree);

        verticalLayout_5 = new QVBoxLayout();
        verticalLayout_5->setObjectName(QString::fromUtf8("verticalLayout_5"));
        verticalLayout_5->setContentsMargins(0, -1, -1, -1);
        label = new QLabel(centralwidget);
        label->setObjectName(QString::fromUtf8("label"));

        verticalLayout_5->addWidget(label);

        listWidget = new QListWidget(centralwidget);
        listWidget->setObjectName(QString::fromUtf8("listWidget"));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Expanding);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(listWidget->sizePolicy().hasHeightForWidth());
        listWidget->setSizePolicy(sizePolicy);
        listWidget->setMinimumSize(QSize(300, 0));
        listWidget->setMaximumSize(QSize(100, 16777215));

        verticalLayout_5->addWidget(listWidget);

        label_2 = new QLabel(centralwidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        verticalLayout_5->addWidget(label_2);

        path = new QLineEdit(centralwidget);
        path->setObjectName(QString::fromUtf8("path"));
        QSizePolicy sizePolicy1(QSizePolicy::Minimum, QSizePolicy::Fixed);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(path->sizePolicy().hasHeightForWidth());
        path->setSizePolicy(sizePolicy1);

        verticalLayout_5->addWidget(path);

        label_3 = new QLabel(centralwidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        verticalLayout_5->addWidget(label_3);

        msg_to_publish = new QPlainTextEdit(centralwidget);
        msg_to_publish->setObjectName(QString::fromUtf8("msg_to_publish"));
        QSizePolicy sizePolicy2(QSizePolicy::Minimum, QSizePolicy::Expanding);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(msg_to_publish->sizePolicy().hasHeightForWidth());
        msg_to_publish->setSizePolicy(sizePolicy2);

        verticalLayout_5->addWidget(msg_to_publish);

        pushButton = new QPushButton(centralwidget);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));

        verticalLayout_5->addWidget(pushButton);


        horizontalLayout->addLayout(verticalLayout_5);


        verticalLayout_2->addLayout(horizontalLayout);

        MessagePool->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MessagePool);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 1118, 22));
        MessagePool->setMenuBar(menubar);
        statusbar = new QStatusBar(MessagePool);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MessagePool->setStatusBar(statusbar);

        retranslateUi(MessagePool);

        QMetaObject::connectSlotsByName(MessagePool);
    } // setupUi

    void retranslateUi(QMainWindow *MessagePool)
    {
        MessagePool->setWindowTitle(QApplication::translate("MessagePool", "MainWindow", nullptr));
        topic->setText(QApplication::translate("MessagePool", "Topic path", nullptr));
        message->setText(QApplication::translate("MessagePool", "Message", nullptr));
        pushButton_3->setText(QApplication::translate("MessagePool", "Send", nullptr));
        label->setText(QApplication::translate("MessagePool", "History", nullptr));
        label_2->setText(QApplication::translate("MessagePool", "Topic path", nullptr));
        label_3->setText(QApplication::translate("MessagePool", "Message", nullptr));
        pushButton->setText(QApplication::translate("MessagePool", "Publish", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MessagePool: public Ui_MessagePool {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MESSAGEPOOL_H
